class ErrorSinRecorrido:
	def __init__(self):
		self.mensaje = "No se encontro recorrido"

	def Error(self) -> str:
		return self.mensaje